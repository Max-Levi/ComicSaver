"use strict";
/* Build flag: flipped to true by the QA deploy script for the QA site. */
const IS_QA = false;
/* Build flag: flipped to true by the extension build script for the Chrome extension. */
const IS_EXTENSION = true;

/* ================= helpers ================= */
const $ = (id) => document.getElementById(id);
const LS = {
  theme: 'comicsaver-theme',
  lastFolder: 'comicsaver-last-folder',
  linked: 'comicsaver-linked-images',
  picker: 'comicsaver-picker-mode',
};
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function toast(msg, isErr){
  const el = document.createElement('div');
  el.className = 'toast' + (isErr ? ' error' : '');
  el.textContent = msg;
  $('toasts').appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .4s'; el.style.opacity = '0';
    setTimeout(() => el.remove(), 450);
  }, 4200);
}

/* ================= QA badge (flipped on by the QA deploy script) ================= */
if (IS_QA){
  document.title += ' — QA';
  const b = document.createElement('span');
  b.className = 'qa-badge'; b.textContent = 'QA';
  document.querySelector('.brand').appendChild(b);
}

/* ================= modals ================= */
function closeOverlays(){
  document.querySelectorAll('.modal-overlay.open').forEach(o => o.classList.remove('open'));
}
document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', closeOverlays));
document.querySelectorAll('.modal-overlay').forEach(o =>
  o.addEventListener('click', e => { if (e.target === o) closeOverlays(); }));
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeOverlays(); });
$('btnConfig').addEventListener('click', () => $('configOverlay').classList.add('open'));
$('btnHelp').addEventListener('click', () => $('helpOverlay').classList.add('open'));
$('btnDocs').addEventListener('click', () => {
  $('helpOverlay').classList.remove('open');
  $('docsOverlay').classList.add('open');
});

/* ================= configuration ================= */
function syncThemeButtons(){
  const cur = localStorage.getItem(LS.theme) || 'dark';
  document.querySelectorAll('#configThemeToggle .mode-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.themeChoice === cur));
}
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
  localStorage.setItem(LS.theme, t);
  syncThemeButtons();
}
document.querySelectorAll('#configThemeToggle .mode-btn').forEach(b =>
  b.addEventListener('click', () => applyTheme(b.dataset.themeChoice)));

$('configLinked').checked = localStorage.getItem(LS.linked) === '1';
$('configLinked').addEventListener('change', e =>
  localStorage.setItem(LS.linked, e.target.checked ? '1' : '0'));

function syncPickerButtons(){
  const cur = localStorage.getItem(LS.picker) || 'reuse';
  document.querySelectorAll('#configPickerToggle .mode-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.pickerChoice === cur));
}
document.querySelectorAll('#configPickerToggle .mode-btn').forEach(b =>
  b.addEventListener('click', () => {
    localStorage.setItem(LS.picker, b.dataset.pickerChoice);
    syncPickerButtons();
  }));

/* ================= loading a page ================= */
const state = { images: [], baseUrl: '', dirHandle: null, downloading: false };

function normalizeUrl(raw){
  raw = (raw || '').trim();
  if (!raw) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(raw)) raw = 'https://' + raw;
  return raw;
}
function setLoading(on){
  $('selectCard').hidden = false;
  $('saveCard').hidden = true;
  $('selCount').textContent = '';
  $('grid').innerHTML = on
    ? '<div class="spinner-row"><div class="spinner"></div>Loading images…</div>'
    : '';
}
async function loadFromUrl(){
  const url = normalizeUrl($('urlInput').value);
  if (!url){ toast('Paste a page URL first.', true); return; }
  $('urlInput').value = url;
  $('pastePanel').hidden = true;
  setLoading(true);
  try{
    const res = await fetch(url, { mode: 'cors', credentials: 'omit', redirect: 'follow' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = await res.text();
    if (!/^\s*</.test(html)) throw new Error('not-html');
    ingest(html, res.url || url);
  }catch(err){
    setLoading(false);
    $('selectCard').hidden = true;
    $('pastePanel').hidden = false;
    $('pasteHtml').value = '';
    toast('That page blocks direct reading (CORS). Paste its source below instead.', true);
  }
}
$('btnLoad').addEventListener('click', loadFromUrl);
$('urlInput').addEventListener('keydown', e => { if (e.key === 'Enter') loadFromUrl(); });
$('btnPasteCancel').addEventListener('click', () => { $('pastePanel').hidden = true; });
$('btnParsePasted').addEventListener('click', () => {
  const html = $('pasteHtml').value;
  if (!html.trim()){ toast('Paste the page source first.', true); return; }
  const base = normalizeUrl($('urlInput').value) || location.href;
  ingest(html, base);
});

/* ================= image extraction ================= */
function pickLargestSrcset(ss){
  let best = null, bestScore = -1;
  for (const part of ss.split(',')){
    const tokens = part.trim().split(/\s+/).filter(Boolean);
    if (!tokens.length) continue;
    const u = tokens[0], d = tokens[1] || '';
    let score = 0;
    const mw = d.match(/^(\d+)w$/), mx = d.match(/^([\d.]+)x$/);
    if (mw) score = +mw[1];
    else if (mx) score = +mx[1] * 100000;
    if (score >= bestScore){ bestScore = score; best = u; }
  }
  return best;
}
const LAZY_ATTRS = ['data-src','data-srcset','data-lazy-src','data-lazy-srcset',
  'data-original','data-fullsrc','data-image','data-hi-res-src','data-zoom-src'];
const IMG_EXT = /\.(jpe?g|png|gif|webp|avif|bmp|svg)(\?|#|$)/i;

function extractImages(html, base){
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const seen = new Set(), out = [];
  const push = (u) => {
    if (!u) return;
    u = u.trim();
    if (!u || u.startsWith('#')) return;
    let abs;
    try{ abs = new URL(u, base).href; }catch(e){ return; }
    /* Check the scheme AFTER resolution: the URL parser strips tabs/newlines,
       so "java\tscript:…" would otherwise resolve to a javascript: URL. */
    if (/^javascript:/i.test(abs)) return;
    if (abs.startsWith('data:') && !abs.startsWith('data:image/')) return;
    if (seen.has(abs)) return;
    seen.add(abs);
    out.push(abs);
  };
  doc.querySelectorAll('img').forEach(img => {
    push(img.getAttribute('src'));
    const ss = img.getAttribute('srcset');
    if (ss) push(pickLargestSrcset(ss));
    for (const a of LAZY_ATTRS){
      const v = img.getAttribute(a);
      if (v) push(/srcset/i.test(a) ? pickLargestSrcset(v) : v);
    }
  });
  doc.querySelectorAll('picture source[srcset], source[srcset]').forEach(s =>
    push(pickLargestSrcset(s.getAttribute('srcset'))));
  if (localStorage.getItem(LS.linked) === '1'){
    doc.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && IMG_EXT.test(h)) push(h);
    });
  }
  return out;
}

/* ================= grid + selection ================= */
function shortName(url){
  if (url.startsWith('data:')) return 'embedded image';
  try{
    const p = new URL(url).pathname;
    const n = decodeURIComponent(p.split('/').pop() || '');
    return n || url;
  }catch(e){ return url; }
}
function ingest(html, base){
  setLoading(false);
  const urls = extractImages(html, base);
  state.images = urls.map((url, i) => ({ url, kept: true, id: i }));
  state.baseUrl = base;
  $('pastePanel').hidden = true;
  $('selectCard').hidden = false;
  $('saveCard').hidden = false;
  renderGrid();
  updateCount();
  updateWillSaveTo();
  $('selectCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
  toast(urls.length
    ? `Found ${urls.length} image${urls.length === 1 ? '' : 's'} — all selected.`
    : 'No images found on that page.', !urls.length);
}
function renderGrid(){
  const grid = $('grid');
  grid.innerHTML = '';
  if (!state.images.length){
    grid.innerHTML = IS_EXTENSION
      ? '<div class="empty-note">No images found. Try the icon on another page.</div>'
      : '<div class="empty-note">No images found. Try another page — or paste the page source if the site blocks direct fetching.</div>';
    return;
  }
  for (const img of state.images){
    const label = document.createElement('label');
    label.className = 'tile kept';
    label.title = img.url;
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = true;
    cb.setAttribute('aria-label', 'Keep this image');
    cb.addEventListener('change', () => {
      img.kept = cb.checked;
      label.classList.toggle('kept', cb.checked);
      label.classList.toggle('dropped', !cb.checked);
      updateCount();
    });
    const im = document.createElement('img');
    im.className = 'thumb'; im.loading = 'lazy'; im.alt = '';
    /* Strip the referrer: many sites block hotlinking by rejecting requests
       whose Referer is some other site, while still serving requests with no
       referrer at all (direct visits/bookmarks). This makes previews load on
       a large class of such sites. */
    im.setAttribute('referrerpolicy', 'no-referrer');
    im.addEventListener('error', () => {
      const d = document.createElement('div');
      d.className = 'thumb-failed';
      d.textContent = 'Preview unavailable — the file may still download.';
      im.replaceWith(d);
    });
    im.src = img.url;
    const cap = document.createElement('div');
    cap.className = 'cap'; cap.textContent = shortName(img.url);
    label.append(cb, im, cap);
    grid.appendChild(label);
  }
}
function setAll(kept){
  state.images.forEach(i => i.kept = kept);
  document.querySelectorAll('#grid .tile').forEach(t => {
    t.classList.toggle('kept', kept);
    t.classList.toggle('dropped', !kept);
    t.querySelector('input').checked = kept;
  });
  updateCount();
}
$('btnSelectAll').addEventListener('click', () => setAll(true));
$('btnSelectNone').addEventListener('click', () => setAll(false));
function updateCount(){
  const kept = state.images.filter(i => i.kept).length;
  $('selCount').innerHTML = `<strong>${kept}</strong> of ${state.images.length} selected`;
  $('btnDownload').disabled = kept === 0 || state.downloading;
}

/* ================= folder naming ================= */
function lastFolder(){ return localStorage.getItem(LS.lastFolder) || ''; }
function suggestFolderName(){
  const last = lastFolder();
  if (!last) return 'batch-1';
  const m = last.match(/^(.*?)(\d+)$/);
  if (m) return m[1] + (parseInt(m[2], 10) + 1);
  return last + ' 2';
}
function resolveFolderName(){
  let name = $('folderInput').value.trim() || suggestFolderName();
  if (IS_QA) name += ' QA';
  return name;
}
function updateWillSaveTo(){
  const suggestion = suggestFolderName();
  $('folderInput').placeholder = 'e.g. ' + suggestion;
  const strong = document.createElement('strong');
  if (IS_EXTENSION){
    /* Preview the sequential file naming: <name>_001 … <name>_00N. */
    const name = resolveFolderName();
    const n = Math.max(state.images.filter(i => i.kept).length, 1);
    const digits = Math.max(3, String(n).length);
    strong.textContent = n > 1
      ? `${name}_001 … ${name}_` + String(n).padStart(digits, '0')
      : `${name}_001`;
    $('willSaveTo').textContent = 'Files will be named: ';
  }else{
    strong.textContent = resolveFolderName();
    $('willSaveTo').textContent = 'Will save to: ';
  }
  $('willSaveTo').appendChild(strong);
}
$('folderInput').addEventListener('input', updateWillSaveTo);
/* Pre-fill the name field with the next suggestion (last name, incremented).
   Runs at startup and after every batch; the user can keep it or type over it.
   Clearing the field manually falls back to the same suggestion, shown as the
   placeholder. */
function prefillFolderInput(){
  $('folderInput').value = suggestFolderName();
  updateWillSaveTo();
}

/* Extension sequential naming keeps each file's original image type. */
function extFor(url){
  if (url.startsWith('data:')){
    const m = url.match(/^data:image\/([a-z0-9+]+)/i);
    let ext = ((m && m[1]) || 'png').toLowerCase().replace('jpeg', 'jpg');
    return '.' + (ext === 'svg+xml' ? 'svg' : ext);
  }
  try{
    const p = new URL(url).pathname;
    const base = decodeURIComponent(p.substring(p.lastIndexOf('/') + 1)).split(/[?#]/)[0];
    const m = base.match(/\.[a-z0-9]{2,5}$/i);
    return m ? m[0].toLowerCase() : '.jpg';
  }catch(e){ return '.jpg'; }
}
/* ================= downloading ================= */
function fileNameFor(url, i, taken){
  let name;
  if (url.startsWith('data:')){
    const m = url.match(/^data:image\/([a-z0-9+]+)/i);
    let ext = ((m && m[1]) || 'png').toLowerCase().replace('jpeg', 'jpg');
    if (ext === 'svg+xml') ext = 'svg';
    name = `image-${i + 1}.${ext}`;
  }else{
    try{
      const p = new URL(url).pathname;
      name = decodeURIComponent(p.substring(p.lastIndexOf('/') + 1)) || `image-${i + 1}`;
    }catch(e){ name = `image-${i + 1}`; }
    name = name.split(/[?#]/)[0].replace(/[\\/:*?"<>|]/g, '_').trim() || `image-${i + 1}`;
    if (!/\.[a-z0-9]{2,5}$/i.test(name)) name += '.jpg';
  }
  let base = name, n = 1;
  while (taken.has(base.toLowerCase())){
    n++;
    const dot = name.lastIndexOf('.');
    base = name.slice(0, dot) + '-' + n + name.slice(dot);
  }
  taken.add(base.toLowerCase());
  return base;
}
function dataUriToBlob(uri){
  const comma = uri.indexOf(',');
  const head = uri.slice(0, comma), data = uri.slice(comma + 1);
  const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/png';
  const bin = atob(data);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
async function fetchImageBlob(url){
  if (url.startsWith('data:')) return dataUriToBlob(url);
  /* no-referrer here for the same anti-hotlinking reason as the thumbnails */
  const res = await fetch(url, { mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return await res.blob();
}
function triggerAnchorDownload(href, path){
  const a = document.createElement('a');
  a.href = href; a.download = path;
  document.body.appendChild(a); a.click(); a.remove();
}
async function getDirHandle(){
  const reuse = (localStorage.getItem(LS.picker) || 'reuse') !== 'every';
  if (state.dirHandle && reuse){
    try{
      if (await state.dirHandle.queryPermission({ mode: 'readwrite' }) === 'granted')
        return state.dirHandle;
    }catch(e){ /* fall through to picker */ }
  }
  if (typeof window.showDirectoryPicker !== 'function') return null;
  try{
    state.dirHandle = await window.showDirectoryPicker({ id: 'comicsaver', mode: 'readwrite' });
    return state.dirHandle;
  }catch(e){ return 'denied'; } /* user cancelled */
}
function resetDownloadUI(){
  state.downloading = false;
  setTimeout(() => {
    $('progressWrap').style.display = 'none';
    $('progressBar').style.width = '0%';
    $('progressLabel').textContent = '';
    updateCount();
  }, 600);
  updateWillSaveTo();
}
function renderFailedList(failed){
  const fl = $('failedList');
  fl.style.display = 'none';
  fl.innerHTML = '';
  if (!failed.length) return;
  fl.style.display = 'block';
  const p = document.createElement('div');
  p.innerHTML = `<strong style="color:var(--text)">${failed.length} file${failed.length === 1 ? '' : 's'} couldn't be downloaded</strong> (the site likely blocks cross-origin reads — open each link to save it by hand):`;
  const ul = document.createElement('ul');
  for (const f of failed){
    const li = document.createElement('li');
    /* Only http(s) and image data: URLs become clickable links — anything
       else (e.g. a smuggled javascript: URL) is shown as inert text. */
    if (/^https?:\/\//i.test(f.url) || /^data:image\//i.test(f.url)){
      const a = document.createElement('a');
      a.href = f.url; a.target = '_blank'; a.rel = 'noopener';
      a.textContent = f.name;
      li.appendChild(a);
    }else{
      li.textContent = f.name + ' (blocked: not a web address)';
    }
    ul.appendChild(li);
  }
  fl.append(p, ul);
}
async function downloadBatch(){
  if (state.downloading) return;
  const kept = state.images.filter(i => i.kept);
  if (!kept.length){ toast('Nothing selected.', true); return; }
  const folder = resolveFolderName();
  /* Capture the user-facing name now (without any QA stamp): the input may
     change while the batch is downloading, and the stored name must be the
     one this batch actually used. */
  const folderBase = $('folderInput').value.trim() || suggestFolderName();
  if (IS_EXTENSION){ await downloadBatchExtension(kept, folder, folderBase); return; }
  state.downloading = true;
  $('btnDownload').disabled = true;
  $('progressWrap').style.display = 'block';
  $('failedList').style.display = 'none';
  $('failedList').innerHTML = '';

  const dir = await getDirHandle();
  if (dir === 'denied'){ resetDownloadUI(); toast('Folder picker was cancelled.', true); return; }
  let sub = null;
  const useFs = !!dir;
  if (useFs){
    try{ sub = await dir.getDirectoryHandle(folder, { create: true }); }
    catch(e){ resetDownloadUI(); toast('Could not create the folder: ' + e.message, true); return; }
  }else{
    toast('This browser has no folder picker — files will save into your Downloads folder, each named “' + folder + '_…”, so the batch stays grouped.');
  }

  const taken = new Set();
  const failed = [];
  let saved = 0, unverified = 0;
  for (let k = 0; k < kept.length; k++){
    const img = kept[k];
    const fname = fileNameFor(img.url, k, taken);
    $('progressLabel').textContent = `Saving ${k + 1} of ${kept.length} — ${fname}`;
    try{
      const blob = await fetchImageBlob(img.url);
      if (useFs){
        const fh = await sub.getFileHandle(fname, { create: true });
        const w = await fh.createWritable();
        await w.write(blob);
        await w.close();
      }else{
        /* Anchor downloads can't create subfolders (browsers flatten any "/"
           in the download name), so prefix each file with the folder name to
           keep the batch grouped in the Downloads folder. */
        const objUrl = URL.createObjectURL(blob);
        triggerAnchorDownload(objUrl, folder + '_' + fname);
        await sleep(300);
        URL.revokeObjectURL(objUrl);
      }
      saved++;
    }catch(e){
      if (!useFs){
        /* Last resort: a plain download of the URL needs no CORS (Chrome/Edge honor it). */
        triggerAnchorDownload(img.url, folder + '_' + fname);
        await sleep(300);
        unverified++;
      }else{
        failed.push({ url: img.url, name: fname });
      }
    }
    $('progressBar').style.width = Math.round(((k + 1) / kept.length) * 100) + '%';
  }

  /* Remember the name for next batch's suggestion (without the QA stamp). */
  localStorage.setItem(LS.lastFolder, folderBase);
  prefillFolderInput(); /* next suggestion ready for the following batch */

  renderFailedList(failed);
  resetDownloadUI();
  const where = useFs ? `into “${folder}”` : `into your Downloads folder as “${folder}_…” files`;
  let msg = `Saved ${saved} image${saved === 1 ? '' : 's'} ${where}.`;
  if (unverified) msg += ` ${unverified} more were sent to the browser directly (couldn't verify).`;
  if (failed.length) msg += ` ${failed.length} failed — see the list below.`;
  toast(msg, failed.length > 0);
}
$('btnDownload').addEventListener('click', downloadBatch);

/* ================= extension download path ================= */
/* The Chrome extension saves through chrome.downloads straight into the
   Downloads folder. Every file is renamed to <name>_001.ext,
   <name>_002.ext, … so the batch stays together and sorts in page order. */
async function downloadBatchExtension(kept, folder, folderBase){
  state.downloading = true;
  $('btnDownload').disabled = true;
  $('progressWrap').style.display = 'block';
  $('failedList').style.display = 'none';
  $('failedList').innerHTML = '';
  $('extOpenRow').hidden = true;

  const safeName = folder.replace(/[\\/:*?"<>|]/g, '_').trim() || 'batch';
  const digits = Math.max(3, String(kept.length).length);
  const seqName = (k) => safeName + '_' + String(k + 1).padStart(digits, '0') + extFor(kept[k].url);
  const failed = [];
  const pending = new Map(); /* downloadId -> { url, name } */
  const requested = new Map(); /* downloadId -> requested filename */
  const onChanged = (delta) => {
    if (!pending.has(delta.id)) return;
    const rec = pending.get(delta.id);
    const st = delta.state && delta.state.current;
    if (st === 'complete'){ pending.delete(delta.id); }
    else if (st === 'interrupted'){
      pending.delete(delta.id);
      failed.push({ url: rec.url, name: rec.name });
    }
  };
  chrome.downloads.onChanged.addListener(onChanged);
  try{
    for (let k = 0; k < kept.length; k++){
      const img = kept[k];
      const fname = seqName(k);
      $('progressLabel').textContent = `Saving ${k + 1} of ${kept.length} — ${fname}`;
      try{
        const id = await chrome.downloads.download({
          url: img.url,
          filename: fname,
          conflictAction: 'uniquify',
          saveAs: false
        });
        pending.set(id, { url: img.url, name: fname });
        requested.set(id, fname);
      }catch(e){
        failed.push({ url: img.url, name: fname });
      }
      $('progressBar').style.width = Math.round(((k + 1) / kept.length) * 100) + '%';
      await sleep(150);
    }
    /* Wait for the downloads to settle; anything still hanging after two
       minutes (or reported interrupted) goes on the failed list. */
    const deadline = Date.now() + 120000;
    while (pending.size && Date.now() < deadline) await sleep(500);
    for (const [id, rec] of [...pending]){
      let interrupted = true;
      try{
        const found = await chrome.downloads.search({ id });
        if (found && found[0] && found[0].state === 'complete') interrupted = false;
      }catch(e){ /* treat as failed */ }
      if (interrupted) failed.push({ url: rec.url, name: rec.name });
      pending.delete(id);
    }
  }finally{
    chrome.downloads.onChanged.removeListener(onChanged);
  }

  localStorage.setItem(LS.lastFolder, folderBase);
  prefillFolderInput(); /* next suggestion ready for the following batch */

  renderFailedList(failed);
  resetDownloadUI();
  const okCount = kept.length - failed.length;
  /* Chrome silently ignores our requested filename when another extension
     manages downloads (it registers an onDeterminingFilename listener), so
     the batch can land with original website names. Detect that by comparing
     each completed download's real filename against what we asked for. */
  let renamedOk = true;
  for (const [id, fname] of requested){
    try{
      const found = await chrome.downloads.search({ id });
      const item = found && found[0];
      if (!item || item.state !== 'complete') continue;
      const landed = (item.filename || '').split(/[/\\]/).pop();
      /* uniquify may append " (1)"; anything not starting with our base name
         means Chrome didn't apply the requested name at all. */
      if (landed && !landed.startsWith(safeName + '_')) renamedOk = false;
    }catch(e){ /* can't verify this one; don't cry wolf */ }
  }
  /* Offer the Downloads-folder shortcut when at least one file landed.
     (Only an extension can do this — web pages are forbidden from opening
     the file manager.) */
  if (okCount > 0){
    $('extOpenRow').hidden = false;
  }
  const range = kept.length > 1
    ? `“${seqName(0)}” … “${seqName(kept.length - 1)}”`
    : `“${seqName(0)}”`;
  if (okCount > 0 && !renamedOk){
    toast(`Saved ${okCount} file${okCount === 1 ? '' : 's'}, but Chrome kept their original website names instead of ${range}. This happens when another extension manages your downloads — try disabling any download-manager extension and running the batch again.`, true);
  }else{
    toast(failed.length
      ? `Saved ${okCount} of ${kept.length} as ${range} in your Downloads folder. ${failed.length} failed — see the list below.`
      : `Saved ${kept.length} image${kept.length === 1 ? '' : 's'} as ${range} in your Downloads folder.`,
      failed.length > 0);
  }
}

/* ================= extension copy ================= */
/* The extension renames files instead of making folders, and scrapes the
   live tab instead of fetching a URL — rewrite the UI and help copy that
   describe the website flow. Runs at boot when IS_EXTENSION. */
function applyExtensionCopy(){
  const saveCard = $('saveCard');
  const h2 = saveCard.querySelector('h2');
  if (h2) h2.textContent = '3 · Name the files';
  const hint = saveCard.querySelector('.hint');
  if (hint) hint.textContent = 'Each file is saved with the name you choose plus a sequential number, so the batch stays in order in your Downloads folder. The name is filled in for you from your last batch (bumping any number at the end) — keep it or type your own.';
  const label = saveCard.querySelector('label[for="folderInput"]');
  if (label) label.innerHTML = 'File name <span style="font-weight:400">(optional)</span>';
  const help = document.querySelector('#helpOverlay .help-content');
  if (help) help.innerHTML =
    '<h3>What it does</h3>' +
    '<p>ComicSaver reads the tab you clicked the toolbar button on, lists every image on it as thumbnails, lets you drop the ones you don\'t want, then saves the rest into your Downloads folder with sequential file names.</p>' +
    '<h3>The three steps</h3>' +
    '<ul>' +
    '<li><strong>Scrape the tab.</strong> Click the ComicSaver toolbar button while viewing a page. ComicSaver reads the live page directly — no URL to paste, no CORS limits — and pulls out its images: <code>&lt;img&gt;</code> tags (including <code>srcset</code> and lazy-load attributes), <code>&lt;picture&gt;</code> sources, and — if enabled in Configuration — links that point at image files.</li>' +
    '<li><strong>Choose images.</strong> Everything starts selected. Click a thumbnail or its checkbox to deselect it. <em>Select all</em> / <em>Select none</em> are there for big batches.</li>' +
    '<li><strong>Name the files.</strong> The name is filled in for you from your last batch, incrementing any number at the end (e.g. <code>Chapter 3</code> → <code>Chapter 4</code>) — keep it or type your own. The first batch ever is called <code>batch-1</code>. Files are saved as <code>&lt;name&gt;_001.jpg</code>, <code>&lt;name&gt;_002.jpg</code>, … so the batch stays in page order.</li>' +
    '</ul>' +
    '<h3>Where the files go</h3>' +
    '<ul>' +
    '<li>Straight into your Downloads folder, renamed <code>&lt;name&gt;_001.jpg</code>, <code>&lt;name&gt;_002.jpg</code>, … in page order.</li>' +
    '<li>If a file can\'t be downloaded (for example, the site blocks it), it lands in a failed list after the batch with a link so you can save it by hand.</li>' +
    '</ul>' +
    '<h3>Why some pages show no images</h3>' +
    '<p>The extension reads the live tab directly, so the CORS limits that affect the website don\'t apply here. If a page shows no images, it genuinely has none in its markup — CSS background images aren\'t collected.</p>';
}

/* ================= extension boot ================= */
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
/* In the extension the images were already scraped from the live tab by the
   content script — no URL fetching or CORS involved. The payload waits in
   chrome.storage.session, put there by the background worker. */
function ingestExtension(payload){
  const urls = [...(payload.images || [])];
  if (localStorage.getItem(LS.linked) === '1') urls.push(...(payload.linkedImages || []));
  const seen = new Set(), uniq = [];
  for (const u of urls){ if (u && !seen.has(u)){ seen.add(u); uniq.push(u); } }
  state.images = uniq.map((url, i) => ({ url, kept: true, id: i }));
  state.baseUrl = payload.pageUrl || '';
  $('selectCard').hidden = false;
  $('saveCard').hidden = false;
  renderGrid();
  updateCount();
  updateWillSaveTo();
  toast(uniq.length
    ? `Found ${uniq.length} image${uniq.length === 1 ? '' : 's'} — all selected.`
    : 'No images found on that page.', !uniq.length);
}
/* ================= extension self-update check ================= */
/* Unpacked extensions don't auto-update, so the app page checks a version
   file on the (unlisted) ComicSaver site each time it opens. GitHub Pages
   sends Access-Control-Allow-Origin: *, so no extra permission is needed. */
const EXT_UPDATE_URL = 'https://max-levi.github.io/ComicSaver/ext-version.json';
function cmpVersions(a, b){
  const pa = String(a).split('.').map(x => parseInt(x, 10) || 0);
  const pb = String(b).split('.').map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++){
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
async function checkExtensionUpdate(){
  let cur = '';
  try{ cur = chrome.runtime.getManifest().version; }catch(e){ return; }
  let info = null;
  try{
    const res = await fetch(EXT_UPDATE_URL, { cache: 'no-store' });
    if (!res.ok) return;
    info = await res.json();
  }catch(e){ return; } /* offline or unreachable: stay silent */
  const latest = info && info.version;
  if (!latest || cmpVersions(latest, cur) <= 0) return;
  if (localStorage.getItem('comicsaver-ext-update-dismissed') === latest) return;
  $('extCurVer').textContent = cur;
  $('extUpdateVer').textContent = latest;
  const dlUrl = info.download ||
    ('https://max-levi.github.io/ComicSaver/comicsaver-extension-' + latest + '.zip');
  $('extUpdateDownload').onclick = () => window.open(dlUrl, '_blank', 'noopener');
  $('updateDlLink').href = dlUrl;
  $('updateDlLink').target = '_blank';
  $('extUpdateBanner').hidden = false;
}
$('extUpdateHow').addEventListener('click', () => $('updateOverlay').classList.add('open'));
$('btnUpdateOpenDl').addEventListener('click', () => {
  try{ chrome.downloads.showDefaultFolder(); }
  catch(e){ toast('Could not open the Downloads folder.', true); }
});
$('extUpdateDismiss').addEventListener('click', () => {
  const v = $('extUpdateVer').textContent;
  if (v) localStorage.setItem('comicsaver-ext-update-dismissed', v);
  $('extUpdateBanner').hidden = true;
});
async function bootExtension(){
  $('urlCard').hidden = true;
  $('pastePanel').hidden = true;
  const pickerRow = $('pickerRow');
  if (pickerRow) pickerRow.hidden = true; /* no folder picker in the extension */
  $('extBanner').hidden = false;
  let payload = null;
  try{
    payload = (await chrome.storage.session.get('comicsaver-payload'))['comicsaver-payload'] || null;
  }catch(e){ payload = null; }
  if (!payload || payload.error){
    $('selectCard').hidden = false;
    $('grid').innerHTML = '<div class="empty-note">' +
      escapeHtml((payload && payload.error) ||
        'Nothing to show. Click the ComicSaver icon while viewing a page to scrape its images.') +
      '</div>';
    checkExtensionUpdate(); /* fire and forget: silent when offline */
    return;
  }
  const src = $('extSource');
  src.textContent = payload.pageTitle || payload.pageUrl || 'the page';
  if (payload.pageUrl) src.href = payload.pageUrl;
  ingestExtension(payload);
  checkExtensionUpdate(); /* fire and forget: silent when offline */
}

/* ================= init ================= */
applyTheme(localStorage.getItem(LS.theme) || 'dark');
syncPickerButtons();
prefillFolderInput();
if (IS_EXTENSION){
  applyExtensionCopy();
  /* Downloads-folder shortcut: chrome.downloads.showDefaultFolder() opens
     the Downloads folder. */
  $('btnOpenDownloadsFolder').addEventListener('click', () => {
    try{ chrome.downloads.showDefaultFolder(); }
    catch(e){ toast('Could not open the Downloads folder.', true); }
  });
  bootExtension();
}
