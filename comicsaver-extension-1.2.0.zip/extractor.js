/* ComicSaver content script — runs in the page's own tab, so it reads the live
   DOM directly: no CORS fetch, no view-source-and-paste. Mirrors the web
   app's extraction rules (img/src, largest srcset, lazy-load attributes,
   picture/source, optional linked images). */
(() => {
  const LAZY_ATTRS = ['data-src', 'data-srcset', 'data-lazy-src', 'data-lazy-srcset',
    'data-original', 'data-fullsrc', 'data-image', 'data-hi-res-src', 'data-zoom-src'];
  const IMG_EXT = /\.(jpe?g|png|gif|webp|avif|bmp|svg)(\?|#|$)/i;

  function pickLargestSrcset(ss) {
    let best = null, bestScore = -1;
    for (const part of String(ss).split(',')) {
      const tokens = part.trim().split(/\s+/).filter(Boolean);
      if (!tokens.length) continue;
      const u = tokens[0], d = tokens[1] || '';
      let score = 0;
      const mw = d.match(/^(\d+)w$/), mx = d.match(/^([\d.]+)x$/);
      if (mw) score = +mw[1];
      else if (mx) score = +mx[1] * 100000;
      if (score >= bestScore) { bestScore = score; best = u; }
    }
    return best;
  }

  const seen = new Set();
  const images = [];
  const linkedImages = [];
  const push = (arr, u) => {
    if (!u) return;
    u = String(u).trim();
    if (!u || u.startsWith('#') || /^javascript:/i.test(u)) return;
    let abs;
    try { abs = new URL(u, document.baseURI).href; } catch (e) { return; }
    if (abs.startsWith('data:') && !abs.startsWith('data:image/')) return;
    if (seen.has(abs)) return;
    seen.add(abs);
    arr.push(abs);
  };

  document.querySelectorAll('img').forEach(img => {
    push(images, img.getAttribute('src') || img.currentSrc);
    const ss = img.getAttribute('srcset');
    if (ss) push(images, pickLargestSrcset(ss));
    for (const a of LAZY_ATTRS) {
      const v = img.getAttribute(a);
      if (v) push(images, /srcset/i.test(a) ? pickLargestSrcset(v) : v);
    }
  });
  document.querySelectorAll('picture source[srcset], source[srcset]').forEach(s =>
    push(images, pickLargestSrcset(s.getAttribute('srcset'))));
  document.querySelectorAll('a[href]').forEach(a => {
    const h = a.getAttribute('href');
    if (h && IMG_EXT.test(h)) push(linkedImages, h);
  });

  return { images, linkedImages };
})();
