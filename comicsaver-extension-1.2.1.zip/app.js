"use strict";
/* Build flag: flipped to true by the QA deploy script for the QA site. */
const IS_QA = false;
/* Build flag: flipped to true by the extension build script for the Chrome extension. */
const IS_EXTENSION = true;

/* ================= helpers ================= */
const $ = (id) => document.getElementById(id);
const LS = {
  theme: 'comicsaver-theme',
  lastFolder: 'comicsaver-last-folder',
  linked: 'comicsaver-linked-images',
  picker: 'comicsaver-picker-mode',
  /* Extension only: remembers whether this Chrome honors subdirectories in
     the downloads API filename ('1' yes, '0' no, absent = not yet verified). */
  subpath: 'comicsaver-ext-subpath',
};
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function toast(msg, isErr){
  const el = document.createElement('div');
  el.className = 'toast' + (isErr ? ' error' : '');
  el.textContent = msg;
  $('toasts').appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .4s'; el.style.opacity = '0';
    setTimeout(() => el.remove(), 450);
  }, 4200);
}

/* ================= QA badge (flipped on by the QA deploy script) ================= */
if (IS_QA){
  document.title += ' — QA';
  const b = document.createElement('span');
  b.className = 'qa-badge'; b.textContent = 'QA';
  document.querySelector('.brand').appendChild(b);
}

/* ================= modals ================= */
function closeOverlays(){
  document.querySelectorAll('.modal-overlay.open').forEach(o => o.classList.remove('open'));
}
document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', closeOverlays));
document.querySelectorAll('.modal-overlay').forEach(o =>
  o.addEventListener('click', e => { if (e.target === o) closeOverlays(); }));
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeOverlays(); });
$('btnConfig').addEventListener('click', () => $('configOverlay').classList.add('open'));
$('btnHelp').addEventListener('click', () => $('helpOverlay').classList.add('open'));

/* ================= configuration ================= */
function syncThemeButtons(){
  const cur = localStorage.getItem(LS.theme) || 'dark';
  document.querySelectorAll('#configThemeToggle .mode-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.themeChoice === cur));
}
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
  localStorage.setItem(LS.theme, t);
  syncThemeButtons();
}
document.querySelectorAll('#configThemeToggle .mode-btn').forEach(b =>
  b.addEventListener('click', () => applyTheme(b.dataset.themeChoice)));

$('configLinked').checked = localStorage.getItem(LS.linked) === '1';
$('configLinked').addEventListener('change', e =>
  localStorage.setItem(LS.linked, e.target.checked ? '1' : '0'));

function syncPickerButtons(){
  const cur = localStorage.getItem(LS.picker) || 'reuse';
  document.querySelectorAll('#configPickerToggle .mode-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.pickerChoice === cur));
}
document.querySelectorAll('#configPickerToggle .mode-btn').forEach(b =>
  b.addEventListener('click', () => {
    localStorage.setItem(LS.picker, b.dataset.pickerChoice);
    syncPickerButtons();
  }));

/* ================= loading a page ================= */
const state = { images: [], baseUrl: '', dirHandle: null, downloading: false, lastBatchIds: [] };

function normalizeUrl(raw){
  raw = (raw || '').trim();
  if (!raw) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(raw)) raw = 'https://' + raw;
  return raw;
}
function setLoading(on){
  $('selectCard').hidden = false;
  $('saveCard').hidden = true;
  $('selCount').textContent = '';
  $('grid').innerHTML = on
    ? '<div class="spinner-row"><div class="spinner"></div>Loading images…</div>'
    : '';
}
async function loadFromUrl(){
  const url = normalizeUrl($('urlInput').value);
  if (!url){ toast('Paste a page URL first.', true); return; }
  $('urlInput').value = url;
  $('pastePanel').hidden = true;
  setLoading(true);
  try{
    const res = await fetch(url, { mode: 'cors', credentials: 'omit', redirect: 'follow' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = await res.text();
    if (!/^\s*</.test(html)) throw new Error('not-html');
    ingest(html, res.url || url);
  }catch(err){
    setLoading(false);
    $('selectCard').hidden = true;
    $('pastePanel').hidden = false;
    $('pasteHtml').value = '';
    toast('That page blocks direct reading (CORS). Paste its source below instead.', true);
  }
}
$('btnLoad').addEventListener('click', loadFromUrl);
$('urlInput').addEventListener('keydown', e => { if (e.key === 'Enter') loadFromUrl(); });
$('btnPasteCancel').addEventListener('click', () => { $('pastePanel').hidden = true; });
$('btnParsePasted').addEventListener('click', () => {
  const html = $('pasteHtml').value;
  if (!html.trim()){ toast('Paste the page source first.', true); return; }
  const base = normalizeUrl($('urlInput').value) || location.href;
  ingest(html, base);
});

/* ================= image extraction ================= */
function pickLargestSrcset(ss){
  let best = null, bestScore = -1;
  for (const part of ss.split(',')){
    const tokens = part.trim().split(/\s+/).filter(Boolean);
    if (!tokens.length) continue;
    const u = tokens[0], d = tokens[1] || '';
    let score = 0;
    const mw = d.match(/^(\d+)w$/), mx = d.match(/^([\d.]+)x$/);
    if (mw) score = +mw[1];
    else if (mx) score = +mx[1] * 100000;
    if (score >= bestScore){ bestScore = score; best = u; }
  }
  return best;
}
const LAZY_ATTRS = ['data-src','data-srcset','data-lazy-src','data-lazy-srcset',
  'data-original','data-fullsrc','data-image','data-hi-res-src','data-zoom-src'];
const IMG_EXT = /\.(jpe?g|png|gif|webp|avif|bmp|svg)(\?|#|$)/i;

function extractImages(html, base){
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const seen = new Set(), out = [];
  const push = (u) => {
    if (!u) return;
    u = u.trim();
    if (!u || u.startsWith('#') || /^javascript:/i.test(u)) return;
    let abs;
    try{ abs = new URL(u, base).href; }catch(e){ return; }
    if (abs.startsWith('data:') && !abs.startsWith('data:image/')) return;
    if (seen.has(abs)) return;
    seen.add(abs);
    out.push(abs);
  };
  doc.querySelectorAll('img').forEach(img => {
    push(img.getAttribute('src'));
    const ss = img.getAttribute('srcset');
    if (ss) push(pickLargestSrcset(ss));
    for (const a of LAZY_ATTRS){
      const v = img.getAttribute(a);
      if (v) push(/srcset/i.test(a) ? pickLargestSrcset(v) : v);
    }
  });
  doc.querySelectorAll('picture source[srcset], source[srcset]').forEach(s =>
    push(pickLargestSrcset(s.getAttribute('srcset'))));
  if (localStorage.getItem(LS.linked) === '1'){
    doc.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && IMG_EXT.test(h)) push(h);
    });
  }
  return out;
}

/* ================= grid + selection ================= */
function shortName(url){
  if (url.startsWith('data:')) return 'embedded image';
  try{
    const p = new URL(url).pathname;
    const n = decodeURIComponent(p.split('/').pop() || '');
    return n || url;
  }catch(e){ return url; }
}
function ingest(html, base){
  setLoading(false);
  const urls = extractImages(html, base);
  state.images = urls.map((url, i) => ({ url, kept: true, id: i }));
  state.baseUrl = base;
  $('pastePanel').hidden = true;
  $('selectCard').hidden = false;
  $('saveCard').hidden = false;
  renderGrid();
  updateCount();
  updateWillSaveTo();
  $('selectCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
  toast(urls.length
    ? `Found ${urls.length} image${urls.length === 1 ? '' : 's'} — all selected.`
    : 'No images found on that page.', !urls.length);
}
function renderGrid(){
  const grid = $('grid');
  grid.innerHTML = '';
  if (!state.images.length){
    grid.innerHTML = IS_EXTENSION
      ? '<div class="empty-note">No images found. Try the icon on another page.</div>'
      : '<div class="empty-note">No images found. Try another page — or paste the page source if the site blocks direct fetching.</div>';
    return;
  }
  for (const img of state.images){
    const label = document.createElement('label');
    label.className = 'tile kept';
    label.title = img.url;
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = true;
    cb.setAttribute('aria-label', 'Keep this image');
    cb.addEventListener('change', () => {
      img.kept = cb.checked;
      label.classList.toggle('kept', cb.checked);
      label.classList.toggle('dropped', !cb.checked);
      updateCount();
    });
    const im = document.createElement('img');
    im.className = 'thumb'; im.loading = 'lazy'; im.alt = '';
    /* Strip the referrer: many sites block hotlinking by rejecting requests
       whose Referer is some other site, while still serving requests with no
       referrer at all (direct visits/bookmarks). This makes previews load on
       a large class of such sites. */
    im.setAttribute('referrerpolicy', 'no-referrer');
    im.addEventListener('error', () => {
      const d = document.createElement('div');
      d.className = 'thumb-failed';
      d.textContent = 'Preview unavailable — the file may still download.';
      im.replaceWith(d);
    });
    im.src = img.url;
    const cap = document.createElement('div');
    cap.className = 'cap'; cap.textContent = shortName(img.url);
    label.append(cb, im, cap);
    grid.appendChild(label);
  }
}
function setAll(kept){
  state.images.forEach(i => i.kept = kept);
  document.querySelectorAll('#grid .tile').forEach(t => {
    t.classList.toggle('kept', kept);
    t.classList.toggle('dropped', !kept);
    t.querySelector('input').checked = kept;
  });
  updateCount();
}
$('btnSelectAll').addEventListener('click', () => setAll(true));
$('btnSelectNone').addEventListener('click', () => setAll(false));
function updateCount(){
  const kept = state.images.filter(i => i.kept).length;
  $('selCount').innerHTML = `<strong>${kept}</strong> of ${state.images.length} selected`;
  $('btnDownload').disabled = kept === 0 || state.downloading;
}

/* ================= folder naming ================= */
function lastFolder(){ return localStorage.getItem(LS.lastFolder) || ''; }
function suggestFolderName(){
  const last = lastFolder();
  if (!last) return 'batch-1';
  const m = last.match(/^(.*?)(\d+)$/);
  if (m) return m[1] + (parseInt(m[2], 10) + 1);
  return last + ' 2';
}
function resolveFolderName(){
  let name = $('folderInput').value.trim() || suggestFolderName();
  if (IS_QA) name += ' QA';
  return name;
}
function updateWillSaveTo(){
  const suggestion = suggestFolderName();
  $('folderInput').placeholder = 'e.g. ' + suggestion;
  const strong = document.createElement('strong');
  strong.textContent = resolveFolderName();
  $('willSaveTo').textContent = 'Will save to: ';
  $('willSaveTo').appendChild(strong);
}
$('folderInput').addEventListener('input', updateWillSaveTo);

/* ================= downloading ================= */
function fileNameFor(url, i, taken){
  let name;
  if (url.startsWith('data:')){
    const m = url.match(/^data:image\/([a-z0-9+]+)/i);
    let ext = ((m && m[1]) || 'png').toLowerCase().replace('jpeg', 'jpg');
    if (ext === 'svg+xml') ext = 'svg';
    name = `image-${i + 1}.${ext}`;
  }else{
    try{
      const p = new URL(url).pathname;
      name = decodeURIComponent(p.substring(p.lastIndexOf('/') + 1)) || `image-${i + 1}`;
    }catch(e){ name = `image-${i + 1}`; }
    name = name.split(/[?#]/)[0].replace(/[\\/:*?"<>|]/g, '_').trim() || `image-${i + 1}`;
    if (!/\.[a-z0-9]{2,5}$/i.test(name)) name += '.jpg';
  }
  let base = name, n = 1;
  while (taken.has(base.toLowerCase())){
    n++;
    const dot = name.lastIndexOf('.');
    base = name.slice(0, dot) + '-' + n + name.slice(dot);
  }
  taken.add(base.toLowerCase());
  return base;
}
function dataUriToBlob(uri){
  const comma = uri.indexOf(',');
  const head = uri.slice(0, comma), data = uri.slice(comma + 1);
  const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/png';
  const bin = atob(data);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
async function fetchImageBlob(url){
  if (url.startsWith('data:')) return dataUriToBlob(url);
  /* no-referrer here for the same anti-hotlinking reason as the thumbnails */
  const res = await fetch(url, { mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return await res.blob();
}
function triggerAnchorDownload(href, path){
  const a = document.createElement('a');
  a.href = href; a.download = path;
  document.body.appendChild(a); a.click(); a.remove();
}
async function getDirHandle(){
  const reuse = (localStorage.getItem(LS.picker) || 'reuse') !== 'every';
  if (state.dirHandle && reuse){
    try{
      if (await state.dirHandle.queryPermission({ mode: 'readwrite' }) === 'granted')
        return state.dirHandle;
    }catch(e){ /* fall through to picker */ }
  }
  if (typeof window.showDirectoryPicker !== 'function') return null;
  try{
    state.dirHandle = await window.showDirectoryPicker({ id: 'comicsaver', mode: 'readwrite' });
    return state.dirHandle;
  }catch(e){ return 'denied'; } /* user cancelled */
}
function resetDownloadUI(){
  state.downloading = false;
  setTimeout(() => {
    $('progressWrap').style.display = 'none';
    $('progressBar').style.width = '0%';
    $('progressLabel').textContent = '';
    updateCount();
  }, 600);
  updateWillSaveTo();
}
function renderFailedList(failed){
  const fl = $('failedList');
  fl.style.display = 'none';
  fl.innerHTML = '';
  if (!failed.length) return;
  fl.style.display = 'block';
  const p = document.createElement('div');
  p.innerHTML = `<strong style="color:var(--text)">${failed.length} file${failed.length === 1 ? '' : 's'} couldn't be downloaded</strong> (the site likely blocks cross-origin reads — open each link to save it by hand):`;
  const ul = document.createElement('ul');
  for (const f of failed){
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = f.url; a.target = '_blank'; a.rel = 'noopener';
    a.textContent = f.name;
    li.appendChild(a);
    ul.appendChild(li);
  }
  fl.append(p, ul);
}
async function downloadBatch(){
  if (state.downloading) return;
  const kept = state.images.filter(i => i.kept);
  if (!kept.length){ toast('Nothing selected.', true); return; }
  const folder = resolveFolderName();
  /* Capture the user-facing name now (without any QA stamp): the input may
     change while the batch is downloading, and the stored name must be the
     one this batch actually used. */
  const folderBase = $('folderInput').value.trim() || suggestFolderName();
  if (IS_EXTENSION){ await downloadBatchExtension(kept, folder, folderBase); return; }
  state.downloading = true;
  $('btnDownload').disabled = true;
  $('progressWrap').style.display = 'block';
  $('failedList').style.display = 'none';
  $('failedList').innerHTML = '';

  const dir = await getDirHandle();
  if (dir === 'denied'){ resetDownloadUI(); toast('Folder picker was cancelled.', true); return; }
  let sub = null;
  const useFs = !!dir;
  if (useFs){
    try{ sub = await dir.getDirectoryHandle(folder, { create: true }); }
    catch(e){ resetDownloadUI(); toast('Could not create the folder: ' + e.message, true); return; }
  }else{
    toast('This browser has no folder picker — files will save into your Downloads folder, each named “' + folder + '_…”, so the batch stays grouped.');
  }

  const taken = new Set();
  const failed = [];
  let saved = 0, unverified = 0;
  for (let k = 0; k < kept.length; k++){
    const img = kept[k];
    const fname = fileNameFor(img.url, k, taken);
    $('progressLabel').textContent = `Saving ${k + 1} of ${kept.length} — ${fname}`;
    try{
      const blob = await fetchImageBlob(img.url);
      if (useFs){
        const fh = await sub.getFileHandle(fname, { create: true });
        const w = await fh.createWritable();
        await w.write(blob);
        await w.close();
      }else{
        /* Anchor downloads can't create subfolders (browsers flatten any "/"
           in the download name), so prefix each file with the folder name to
           keep the batch grouped in the Downloads folder. */
        const objUrl = URL.createObjectURL(blob);
        triggerAnchorDownload(objUrl, folder + '_' + fname);
        await sleep(300);
        URL.revokeObjectURL(objUrl);
      }
      saved++;
    }catch(e){
      if (!useFs){
        /* Last resort: a plain download of the URL needs no CORS (Chrome/Edge honor it). */
        triggerAnchorDownload(img.url, folder + '_' + fname);
        await sleep(300);
        unverified++;
      }else{
        failed.push({ url: img.url, name: fname });
      }
    }
    $('progressBar').style.width = Math.round(((k + 1) / kept.length) * 100) + '%';
  }

  /* Remember the name for next batch's suggestion (without the QA stamp). */
  localStorage.setItem(LS.lastFolder, folderBase);
  $('folderInput').value = '';

  renderFailedList(failed);
  resetDownloadUI();
  const where = useFs ? `into “${folder}”` : `into your Downloads folder as “${folder}_…” files`;
  let msg = `Saved ${saved} image${saved === 1 ? '' : 's'} ${where}.`;
  if (unverified) msg += ` ${unverified} more were sent to the browser directly (couldn't verify).`;
  if (failed.length) msg += ` ${failed.length} failed — see the list below.`;
  toast(msg, failed.length > 0);
}
$('btnDownload').addEventListener('click', downloadBatch);

/* ================= extension download path ================= */
/* The Chrome extension saves through chrome.downloads, which CAN create real
   subfolders (unlike anchor downloads) — every batch lands in
   Downloads/<folder>/. */
async function downloadBatchExtension(kept, folder, folderBase){
  state.downloading = true;
  $('btnDownload').disabled = true;
  $('progressWrap').style.display = 'block';
  $('failedList').style.display = 'none';
  $('failedList').innerHTML = '';
  $('extOpenRow').hidden = true;

  const safeFolder = folder.replace(/[\\/:*?"<>|]/g, '_').trim() || 'batch';
  /* Some Chrome builds honor subdirectories in the downloads API filename
     (Downloads/<folder>/<file>); others silently ignore them and save flat
     into Downloads. We try the subfolder first and verify afterwards; once
     we know this Chrome ignores them, later batches use <folder>_<file>
     names so the batch still stays grouped. */
  const useSub = localStorage.getItem(LS.subpath) !== '0';
  const taken = new Set();
  const failed = [];
  const completedIds = [];
  const pending = new Map(); /* downloadId -> { url, name } */
  const onChanged = (delta) => {
    if (!pending.has(delta.id)) return;
    const rec = pending.get(delta.id);
    const st = delta.state && delta.state.current;
    if (st === 'complete'){ pending.delete(delta.id); completedIds.push(delta.id); }
    else if (st === 'interrupted'){
      pending.delete(delta.id);
      failed.push({ url: rec.url, name: rec.name });
    }
  };
  chrome.downloads.onChanged.addListener(onChanged);
  try{
    for (let k = 0; k < kept.length; k++){
      const img = kept[k];
      const fname = fileNameFor(img.url, k, taken);
      $('progressLabel').textContent = `Saving ${k + 1} of ${kept.length} — ${fname}`;
      try{
        const id = await chrome.downloads.download({
          url: img.url,
          filename: useSub ? safeFolder + '/' + fname : safeFolder + '_' + fname,
          conflictAction: 'uniquify',
          saveAs: false
        });
        pending.set(id, { url: img.url, name: fname });
      }catch(e){
        failed.push({ url: img.url, name: fname });
      }
      $('progressBar').style.width = Math.round(((k + 1) / kept.length) * 100) + '%';
      await sleep(150);
    }
    /* Wait for the downloads to settle; anything still hanging after two
       minutes (or reported interrupted) goes on the failed list. */
    const deadline = Date.now() + 120000;
    while (pending.size && Date.now() < deadline) await sleep(500);
    for (const [id, rec] of [...pending]){
      let interrupted = true;
      try{
        const found = await chrome.downloads.search({ id });
        if (found && found[0] && found[0].state === 'complete') interrupted = false;
      }catch(e){ /* treat as failed */ }
      if (interrupted) failed.push({ url: rec.url, name: rec.name });
      pending.delete(id);
    }
  }finally{
    chrome.downloads.onChanged.removeListener(onChanged);
  }

  localStorage.setItem(LS.lastFolder, folderBase);
  $('folderInput').value = '';

  renderFailedList(failed);
  resetDownloadUI();
  const okCount = kept.length - failed.length;
  /* Verify where the files actually landed: check the first completed
     download's real path and remember whether this Chrome creates the
     requested subfolder, so future batches (and the toast) are accurate. */
  let inSubfolder = useSub;
  if (okCount > 0 && completedIds.length){
    try{
      const found = await chrome.downloads.search({ id: completedIds[0] });
      const landed = found && found[0] && found[0].filename || '';
      inSubfolder = landed.includes('/' + safeFolder + '/') ||
                    landed.includes('\\' + safeFolder + '\\');
      localStorage.setItem(LS.subpath, inSubfolder ? '1' : '0');
    }catch(e){ /* keep the optimistic assumption */ }
  }
  /* Offer folder shortcuts when at least one file landed: "batch folder"
     reveals the first file in the file manager (inside the new subfolder
     when this Chrome created one), "Downloads folder" opens its parent.
     (Only an extension can do this — web pages are forbidden
     from opening the file manager.) */
  if (okCount > 0 && completedIds.length){
    state.lastBatchIds = completedIds;
    $('extOpenRow').hidden = false;
  }
  const destMsg = inSubfolder
    ? `into “${safeFolder}” in your Downloads folder`
    : `into your Downloads folder named “${safeFolder}_…” (this Chrome doesn’t create subfolders for extension downloads, so the batch is grouped by name instead)`;
  toast(failed.length
    ? `Saved ${okCount} of ${kept.length} ${destMsg}. ${failed.length} failed — see the list below.`
    : `Saved ${kept.length} image${kept.length === 1 ? '' : 's'} ${destMsg}.`,
    failed.length > 0);
}

/* ================= extension boot ================= */
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
/* In the extension the images were already scraped from the live tab by the
   content script — no URL fetching or CORS involved. The payload waits in
   chrome.storage.session, put there by the background worker. */
function ingestExtension(payload){
  const urls = [...(payload.images || [])];
  if (localStorage.getItem(LS.linked) === '1') urls.push(...(payload.linkedImages || []));
  const seen = new Set(), uniq = [];
  for (const u of urls){ if (u && !seen.has(u)){ seen.add(u); uniq.push(u); } }
  state.images = uniq.map((url, i) => ({ url, kept: true, id: i }));
  state.baseUrl = payload.pageUrl || '';
  $('selectCard').hidden = false;
  $('saveCard').hidden = false;
  renderGrid();
  updateCount();
  updateWillSaveTo();
  toast(uniq.length
    ? `Found ${uniq.length} image${uniq.length === 1 ? '' : 's'} — all selected.`
    : 'No images found on that page.', !uniq.length);
}
/* ================= extension self-update check ================= */
/* Unpacked extensions don't auto-update, so the app page checks a version
   file on the (unlisted) ComicSaver site each time it opens. GitHub Pages
   sends Access-Control-Allow-Origin: *, so no extra permission is needed. */
const EXT_UPDATE_URL = 'https://max-levi.github.io/ComicSaver/ext-version.json';
function cmpVersions(a, b){
  const pa = String(a).split('.').map(x => parseInt(x, 10) || 0);
  const pb = String(b).split('.').map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++){
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
async function checkExtensionUpdate(){
  let cur = '';
  try{ cur = chrome.runtime.getManifest().version; }catch(e){ return; }
  let info = null;
  try{
    const res = await fetch(EXT_UPDATE_URL, { cache: 'no-store' });
    if (!res.ok) return;
    info = await res.json();
  }catch(e){ return; } /* offline or unreachable: stay silent */
  const latest = info && info.version;
  if (!latest || cmpVersions(latest, cur) <= 0) return;
  if (localStorage.getItem('comicsaver-ext-update-dismissed') === latest) return;
  $('extCurVer').textContent = cur;
  $('extUpdateVer').textContent = latest;
  $('extUpdateDownload').onclick = () =>
    window.open(info.download ||
      ('https://max-levi.github.io/ComicSaver/comicsaver-extension-' + latest + '.zip'),
      '_blank', 'noopener');
  $('extUpdateBanner').hidden = false;
}
$('extUpdateDismiss').addEventListener('click', () => {
  const v = $('extUpdateVer').textContent;
  if (v) localStorage.setItem('comicsaver-ext-update-dismissed', v);
  $('extUpdateBanner').hidden = true;
});
async function bootExtension(){
  $('urlCard').hidden = true;
  $('pastePanel').hidden = true;
  const pickerRow = $('pickerRow');
  if (pickerRow) pickerRow.hidden = true; /* no folder picker in the extension */
  $('extBanner').hidden = false;
  let payload = null;
  try{
    payload = (await chrome.storage.session.get('comicsaver-payload'))['comicsaver-payload'] || null;
  }catch(e){ payload = null; }
  if (!payload || payload.error){
    $('selectCard').hidden = false;
    $('grid').innerHTML = '<div class="empty-note">' +
      escapeHtml((payload && payload.error) ||
        'Nothing to show. Click the ComicSaver icon while viewing a page to scrape its images.') +
      '</div>';
    checkExtensionUpdate(); /* fire and forget: silent when offline */
    return;
  }
  const src = $('extSource');
  src.textContent = payload.pageTitle || payload.pageUrl || 'the page';
  if (payload.pageUrl) src.href = payload.pageUrl;
  ingestExtension(payload);
  checkExtensionUpdate(); /* fire and forget: silent when offline */
}

/* ================= init ================= */
applyTheme(localStorage.getItem(LS.theme) || 'dark');
syncPickerButtons();
updateWillSaveTo();
if (IS_EXTENSION){
  /* Folder shortcuts: chrome.downloads.show(id) reveals the batch subfolder
     in the file manager with the file highlighted; showDefaultFolder() opens
     the Downloads folder it lives in. */
  $('btnOpenBatchFolder').addEventListener('click', () => {
    const ids = state.lastBatchIds || [];
    if (!ids.length) return;
    try{ chrome.downloads.show(ids[0]); }
    catch(e){ toast('Could not open the folder.', true); }
  });
  $('btnOpenDownloadsFolder').addEventListener('click', () => {
    try{ chrome.downloads.showDefaultFolder(); }
    catch(e){ toast('Could not open the Downloads folder.', true); }
  });
  bootExtension();
}
