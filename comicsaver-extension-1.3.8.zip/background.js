/* ComicSaver background service worker (Manifest V3).
   Clicking the toolbar icon scrapes the active tab's images with the content
   script (activeTab grants one-shot access — no broad host permissions), stashes
   the payload in session storage, and opens the ComicSaver app tab. */
const PAYLOAD_KEY = 'comicsaver-payload';

async function stash(payload) {
  await chrome.storage.session.set({ [PAYLOAD_KEY]: payload });
}

chrome.action.onClicked.addListener(async (tab) => {
  const url = (tab && tab.url) || '';
  if (!tab || !tab.id || !/^(https?|file):/i.test(url)) {
    await stash({ error: 'ComicSaver needs a regular web page. Open the page with the images first, then click the ComicSaver icon.' });
    await chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
    return;
  }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['extractor.js']
    });
    const data = results && results[0] && results[0].result;
    if (!data || !data.images || !data.images.length) {
      await stash({ error: 'No images found on that page.', pageUrl: url, pageTitle: tab.title });
    } else {
      await stash({
        pageUrl: url,
        pageTitle: tab.title,
        images: data.images,
        linkedImages: data.linkedImages || []
      });
    }
  } catch (e) {
    await stash({ error: 'Could not read that page (' + (e && e.message ? e.message : e) + '). Some pages (like the Chrome Web Store) block extensions.' });
  }
  await chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
});
